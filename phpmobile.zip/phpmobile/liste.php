<?php

try
{
$bdd = new PDO('mysql:host=localhost;dbname=myspace', 'root', '');}
catch(Exception $e)
{
  die('Erreur : '.$e->getMessage());
}

   $projetss = $bdd -> query("SELECT * FROM users");
   $projet = $projetss->fetchAll(PDO::FETCH_NUM);
   echo count($projet); 
          
 ?>
        